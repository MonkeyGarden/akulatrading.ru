$(document).ready(function () {
  $(".first-screen-illustration").addClass("static");

  //Слайдер с тарифами
  $(window).on("load resize orientationchange", function () {
    $(".tarifs-slider").each(function () {
      var $tarifSlider = $(this);
      if ($(window).width() > 992) {
        if ($tarifSlider.hasClass("slick-initialized")) {
          $tarifSlider.slick("unslick");
        }
      } else {
        if (!$tarifSlider.hasClass("slick-initialized")) {
          $tarifSlider.on(
            "init reInit afterChange",
            function (event, slick, currentSlide, nextSlide) {
              $(this).css("visibility", "visible");
            }
          );
          $tarifSlider.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            speed: 700,
            arrows: false,
            dots: true,
            infinite: true,
          });
        }
      }
    });
  });

  //Слайдер с программой курсов
  $(window).on("load resize orientationchange", function () {
    $(".course-program-slider").each(function () {
      var $programSlider = $(this);
      if ($(window).width() > 768) {
        if ($programSlider.hasClass("slick-initialized")) {
          $programSlider.slick("unslick");
        }
      } else {
        $(".mobile-course-hidden").remove();
        if (!$programSlider.hasClass("slick-initialized")) {
          $programSlider.on(
            "init reInit afterChange",
            function (event, slick, currentSlide, nextSlide) {
              $(this).css("visibility", "visible");
            }
          );
          $programSlider.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            speed: 700,
            arrows: false,
            dots: true,
            infinite: true,
          });
        }
      }
    });
  });
  //Анимации
  AOS.init({
    startEvent: "DOMContentLoaded",
    once: true,
    disable: "mobile",
    offset: 0,
    anchorPlacement: "top-center",
    disable: function () {
      var maxWidth = 992;
      return window.innerWidth < maxWidth;
    },
  });
  $(window).on("load", function () {
    AOS.refresh();
  });

  //Скролл к блоку
  $("a.go").click(function (e) {
    e.preventDefault();
    let $t = $(this),
      id = $t.attr("href");
    $("html, body").animate(
      {
        scrollTop: $(id).offset().top,
      },
      1200
    );
  });

  //Делаем маску для телефона
  if ($("input[type=tel]").length > 0) {
    $("input[type=tel]").inputmask("+7 (999) 999-99-99");
    $("input[type=tel]").inputmask({
      clearIncomplete: true,
    });
  }

  //Аккордеон с вопросами
  $(".questions-akkorderon__link").click(function (e) {
    e.preventDefault();
    $(this).toggleClass("active");
    $(this).siblings(".questions-akkorderon__content").slideToggle();
  });

  //Изменение активного пункта меню при скроле
  function Scroll_block() {
    var scroll_top = $(document).scrollTop() + 100;
    $(".site-nav a").each(function () {
      var hash = $(this).attr("href");
      var target = $(hash);
      if (
        target.position().top <= scroll_top &&
        target.position().top + target.outerHeight() > scroll_top
      ) {
        $(".site-nav li.active").parent().removeClass("active");
        $(this).parent().addClass("active");
      } else {
        $(this).parent().removeClass("active");
      }
    });
  }
  $(document).on("scroll", Scroll_block);
});
